#include <string>         // std::string
#include <algorithm>      // remove_if
#include <cctype>         // ::isspace


using namespace std;

// removes whitespace and converts to lowercase
void normalize(string& s);
