#include "queue-array.h"

using namespace queue;


/****************************************************************/
/* 			FUNZIONI SULLE CODE 			*/
/****************************************************************/

/****************************************************************/
Queue queue::createEmpty()
{
   Queue q;
   return q;
}

/****************************************************************/
void queue::enqueue(Elem e, Queue& l) // aggiunge e in coda
{
  return;
}


/****************************************************************/
Elem queue::dequeue(Queue& l) // rimuove il primo elemento e lo restituisce
{
   return EMPTYELEM;
}


/****************************************************************/
Elem queue::first(Queue& l) // restituisce il primo elemento
{
   return EMPTYELEM;
}


/****************************************************************/
bool queue::isEmpty(const Queue& l)
{
   return true;
}



/****************************************************************/
Queue readFromFile(string nome_file)
{
    ifstream ifs(nome_file.c_str()); // stream associato a un file, in lettura
    return readFromStream(ifs);
}



Queue readFromStdin()
{
    cout << endl << "inserire una sequenza di numeri separati da spazi seguiti da "
      <<  FINEINPUT << " per terminare" << endl;
    return readFromStream((std::cin));
}



Queue readFromStream(istream& is)
{
   Queue l = createEmpty();        
   Elem e;
   while (is >> e) {
      if (e == FINEINPUT) // il segnale di fine input è FINEINPUT
         return l;
      enqueue(e, l);
   }
   throw runtime_error("errore inserimento dati");
}



void print(const Queue& l)
{
   for (int i=0; i<l.size; ++i)
      cout << l.queue[i] << "; "; 
   cout << endl;
}
