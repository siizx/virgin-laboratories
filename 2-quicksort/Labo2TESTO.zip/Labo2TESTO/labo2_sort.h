#include <vector> 
#include <stdlib.h>     // srand, rand, per quickSortRandom() da implementare

using namespace std;


void selectionSort(vector<int>&);
void insertionSort(vector<int>&);
void bubbleSort(vector<int>&);
void mergeSort(vector<int>&);
void quickSortTrivial(vector<int>&);
void quickSortRandom(vector<int>&);
