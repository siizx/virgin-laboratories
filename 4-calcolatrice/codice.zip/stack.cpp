#include "stack.h"

using namespace stack;

/****************************************************************/
bool stack::isEmpty(const Stack& s)
{
    // DA IMPLEMENTARE
    return true;
}

/****************************************************************/
void stack::push(const Elem x, Stack& s) 
{
    // DA IMPLEMENTARE
}

/****************************************************************/
Elem stack::pop(Stack& s)
{
    // DA IMPLEMENTARE
    Elem e;
    return e;
}

/****************************************************************/

