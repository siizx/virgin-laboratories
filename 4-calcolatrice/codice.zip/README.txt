========================================================================

Laboratorio 4: calcolo di semplici espressioni numeriche 
               mediante pile e code

vengono accettati dall'esterno solo numeri positivi.
Per trattare anche numeri negativi occorre modificare
l'analizzatore lessicale.

========================================================================

token.h
token.cpp
  Header e implementazione del tipo dei token.

queue.h
queue.cpp
  Header e implementazione del tipo coda di token.

stack.h
stack.cpp
  Header e implementazione del tipo pila di token.

main.cpp
  Definisce le due funzioni leggi e calcola e il main che esegue
  la lettura e la valutazione dell'espressione.
========================================================================
